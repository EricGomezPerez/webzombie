
import { useState, useEffect } from "react";

export default function Home() {
  const [data, setData] = useState(null);
  const [selected, setSelected] = useState(null);

  useEffect(() => {
    fetch("/items_data.json")
      .then((res) => res.json())
      .then((json) => setData(json));
  }, []);

  if (!data) return <p className="p-4">Cargando datos...</p>;

  const allItems = Object.values(data).flat();

  const handleSelect = (itemName) => {
    setSelected(itemName);
  };

  const renderItemTree = (item, depth = 0) => {
    const itemData = allItems.find((r) => r[0] === item);
    if (!itemData) return <li key={item}>{item}</li>;

    const needs = itemData.slice(1).filter(Boolean);

    return (
      <li key={item} style={{ marginLeft: depth * 20 }}>
        <strong>{item}</strong>
        {needs.length > 0 && (
          <ul>
            {needs.map((n) => renderItemTree(n, depth + 1))}
          </ul>
        )}
      </li>
    );
  };

  return (
    <div className="p-4 font-sans">
      <h1 className="text-2xl font-bold mb-4">Buscador de Crafteos</h1>
      <select
        className="border p-2 rounded"
        onChange={(e) => handleSelect(e.target.value)}
        defaultValue=""
      >
        <option value="" disabled>
          Selecciona un ítem
        </option>
        {allItems.map((row, i) => (
          <option key={i} value={row[0]}>
            {row[0]}
          </option>
        ))}
      </select>

      {selected && (
        <div className="mt-6">
          <h2 className="text-xl mb-2">Crafteo para: {selected}</h2>
          <ul>{renderItemTree(selected)}</ul>
        </div>
      )}
    </div>
  );
}
