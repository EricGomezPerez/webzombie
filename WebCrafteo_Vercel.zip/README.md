
# Web Crafteo - Lista Jerárquica

Proyecto Next.js listo para subir a **Vercel**.

## Despliegue

1. Sube este ZIP a tu cuenta de **Vercel**.
2. No necesitas configurar nada más.
3. Vercel detectará automáticamente que es un proyecto Next.js.

El archivo `public/items_data.json` contiene los datos exportados del Excel.
